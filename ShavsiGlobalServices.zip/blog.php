<!--
Devloper Name: Sayam Sharma;
Email: sayamsharma.jci@gmail.com;
Created On: 23 may 2021;
Version:1.0.0;
Page Name:query;
-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog | Shavsi Global Services</title>
<!--header file starts from here-->
<?php 
    include "header.php";
    ?>
    <!--header file ends here-->
<!-- jumbo tron starts from here-->
<div class="jumbotron jumbotron-fluid">
		<div class="container">
			<h1 class="display-4">Blog</h1>
			<p class="lead">Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem ducimus nihil laborum obcaecati omnis sit minima consectetur voluptatum blanditiis consequatur! Nesciunt totam suscipit natus consequuntur eveniet possimus nulla accusamus ullam!</p>
		</div>
	</div>
<!-- jumbo tron ends here-->




    
    <!--footer starts from here-->
          <?php 
    include "footer.php";
    ?>
    <!--footer file ends  here-->
    
