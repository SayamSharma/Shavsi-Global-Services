<!--
Devloper Name: Sayam Sharma;
Email: sayamsharma.jci@gmail.com;
Created On: 23 may 2021;
Version:1.0.0;
Page Name:homepage;
-->

<!--  Footer -->
<footer class="page-footer font-small blue pt-4">
<div class="customfooter">
<!-- Footer Links -->
<div class="container-fluid text-center text-md-left">

  <!-- Grid row -->
  <div class="row">

    <!-- Grid column -->
    <div class="col-md-6 mt-md-0 mt-3">

      <!-- Content -->
      <h5 class="text-uppercase"></h5>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ut placeat omnis quos animi doloremque enim error aspernatur recusandae, dolorem unde. Explicabo blanditiis voluptatum optio vero architecto omnis eos, nihil nisi?</p>

    </div>
    <!-- Grid column -->

    <hr class="clearfix w-100 d-md-none pb-3">

    <!-- Grid column -->
    <div class="col-md-3 mb-md-0 mb-3">

      <!-- Links -->
      <h5 class="text-uppercase">Links</h5>

      <ul class="list-unstyled">
        <li>
          <a href="#!">Link 1</a>
        </li>
        <li>
          <a href="#!">Link 2</a>
        </li>
        <li>
          <a href="#!">Link 3</a>
        </li>
        <li>
          <a href="#!">Link 4</a>
        </li>
      </ul>

    </div>
    <!-- Grid column -->
    
    <!-- Grid column -->
    <div class="col-md-3 mb-md-0 mb-3">

      <!-- Links -->
      <h5 class="text-uppercase">Links</h5>

      <ul class="list-unstyled">
        <li>
          <a href="#!">Link 1</a>
        </li>
        <li>
          <a href="#!">Link 2</a>
        </li>
        <li>
          <a href="#!">Link 3</a>
        </li>
        <li>
          <a href="#!">Link 4</a>
        </li>
      </ul>

    </div>
    <!-- Grid column -->

  </div>
  <!-- Grid column -->
  <p style="text-align: center;">
      <!-- Facebook -->
<a class="btn btn-primary" style="background-color: #3b5998;" href="#!" role="button"
  ><i class="fab fa-facebook-f"></i
></a>
      <!-- Twitter -->
<a class="btn btn-primary" style="background-color: #55acee;" href="#!" role="button"
  ><i class="fab fa-twitter"></i
></a>
     <!-- Google -->
<a class="btn btn-primary" style="background-color: #dd4b39;" href="#!" role="button"
  ><i class="fab fa-google"></i
></a>
     <!-- Instagram -->
<a class="btn btn-primary" style="background-color: #ac2bac;" href="#!" role="button"
  ><i class="fab fa-instagram"></i
></a>
      <!-- Linkedin -->
<a class="btn btn-primary" style="background-color: #0082ca;" href="#!" role="button"
  ><i class="fab fa-linkedin-in"></i
></a>
    </p>
    <!-- Grid column -->
  <!-- Grid row -->

</div>
<!-- Footer Links -->

<!-- Copyright -->
<div class="footer-copyright text-center py-3">© 2021 Copyright:
  <a href="#"> Shavsi Global Services</a>
</div>
<!-- Copyright -->
</div>
</footer>
<!-- Footer --> -->
</body>

</html>